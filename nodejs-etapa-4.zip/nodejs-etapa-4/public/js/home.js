// Cuenta regresiva para el Black FRIDAY
const countdownElement = document.getElementById('countdown');

function startCountdown(endDate) {
        const interval = setInterval(() => {
        const now = new Date().getTime();
        const distance = endDate - now;

        const days = Math.floor(distance / (1000 * 60 * 60 * 24));
        const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((distance % (1000 * 60)) / 1000);

        countdownElement.innerHTML = `${days}d ${hours}h ${minutes}m ${seconds}s`;

        if (distance < 0) {
            clearInterval(interval);
            countdownElement.innerHTML = "¡La oferta ha comenzado!";
        }
    }, 1000);
}

const blackFridayDate = new Date("2024-11-27T03:00:00Z").getTime(); 
startCountdown(blackFridayDate);

// Suscripción al newsletter
document.getElementById('newsletter-form').addEventListener('submit', (e) => {
    e.preventDefault();
    alert("¡Gracias por suscribirte!");
});
// Mostrar/Ocultar Respuestas en la Sección FAQ
const faqQuestions = document.querySelectorAll('.faq-question');

faqQuestions.forEach(question => {
    question.addEventListener('click', () => {
        const answer = question.nextElementSibling;
        answer.style.display = answer.style.display === 'block' ? 'none' : 'block';
    });
});
