const { conn } = require('../config/conn');

//obtener todos los productos
const getAll = async () => {
    try {
        const [rows] = await conn.query
        ('SELECT * FROM product; ');
        return rows;
        
    } catch (error) {
        return {
            error: true,
            message: 'Hemos detectado un error: ' + error
        };
    } finally {
        conn.releaseConnection();
    }
}
//obtener todos los productos y su categorias
const getAllInfo = async () => {
    let connection;
    try {
        connection = await conn.getConnection();

        const [rows] = await connection.query(`
            SELECT product.*, category.category_name 
            FROM product 
            LEFT JOIN category ON product.category_id = category.category_id;
        `);

        return rows;
    } catch (error) {
        console.error('Error en getAllInfo:', error);
        throw error;
    } finally {
        if (connection) connection.release();
    }
};


//obtener 1 producto
const getOne = async ({ product_id }) => {
    try {
        const [rows] = await conn.query(
            `SELECT 
                product.*, 
                category.category_name 
             FROM 
                product 
             LEFT JOIN 
                category 
             ON 
                product.category_id = category.category_id 
             WHERE 
                product.product_id = ?`,
            [product_id]
        );
        console.log('Resultado de la consulta:', rows);  // Depuración
        return rows;
    } catch (error) {
        console.error('Error en getOne:', error.message);
        return [];
    }
};



//create item
const create = async(params) =>   {
    try {
        const [product] = await conn.query('INSERT INTO product (product_name, product_description, price, stock, discount, sku, img_product, category_id) VALUES ?;', [params]);

        return product;
    } catch (error) {
        return {
            error: true,
            message: 'hemos encontrado un error en: ' + error
        } 
    } finally {
        conn.releaseConnection();
    }
}

const edit = async(params, id) =>   {
    try {
        const [product] = await conn.query('UPDATE product SET ? WHERE ?', [params, id]);

        return product;
    } catch (error) {
        return {
            error: true,
            message: 'hemos encontrado un error en: ' + error
        } 
    } finally {
        conn.releaseConnection();
    }
}

const deleteOne = async(params) =>   {
    try {
        const [product] = await conn.query('DELETE FROM product WHERE ?', params);
        return product;
    } catch (error) {
        return {
            error: true,
            message: 'hemos encontrado un error en: ' + error
        } 
    } finally {
        conn.releaseConnection();
    }
}

module.exports = {
    getAll, 
    getAllInfo,
    getOne,
    create,
    edit,
    deleteOne
}