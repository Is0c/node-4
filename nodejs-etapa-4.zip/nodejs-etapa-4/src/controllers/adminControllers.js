const { getAllInfo, getOne, create, edit, deleteOne } = require('../models/productModels');

module.exports = {
    admin: async (req, res) => {
        const data = await getAllInfo();
        //console.log(data);

        res.render('admin/admin', {
            title: 'Panel de administración',
            data
        });
        
    },
    createView: (req, res) => {
        
        res.render ('admin/create', {
            title: 'Crear producto'
        });
    },
    createItem: async (req, res) => {

    //importante el orden ya que se crea en este orden
    const product_schema = {
        product_name: req.body.name,
        product_description: req.body.description,
        price: Number(req.body.price),
        stock: Number(req.body.stock),
        discount: Number(req.body.discount),
        sku: req.body.sku,
        image_front: '/products/' + req.files[0].filename,
        category_id: Number(req.body.category)
      }
      await create([Object.values(product_schema)]);
      res.redirect('/admin');
    },

    editView: async (req, res) => {
      try {
          const { id } = req.params;
  
          // Obtenemos el producto
          const [product] = await getOne({ product_id: id });
  
          if (!product) {
              return res.status(404).send('Producto no encontrado');
          }
  
          res.render('admin/edit', {
              title: 'Editar producto',
              product
          });
      } catch (error) {
          console.error('Error al cargar el producto en administración:', error.message);
          res.status(500).send('Error interno del servidor');
      }
  },
  
  

  editItem: async (req, res) => {
    try {
        console.log('ID:', req.params.id);
        console.log('Body:', req.body);

        const { id } = req.params;

        // Manejo seguro de req.files
        const haveImages = req.files && req.files.length > 0;

        // Construcción del esquema del producto
        const product_schema = {
            product_name: req.body.name || '',
            product_description: req.body.description || '',
            price: Number(req.body.price) || 0,
            stock: Number(req.body.stock) || 0,
            discount: Number(req.body.discount) || 0,
            sku: req.body.sku || '',
            category_id: Number(req.body.category) || null,
            ...(haveImages && { image_front: '/products/' + req.files[0].filename }) // Solo agrega la imagen si existe
        };

        // Actualización del producto
        const updateResult = await edit(product_schema, { product_id: id });

        // Comprueba si la actualización fue exitosa
        if (!updateResult) {
            return res.status(400).send('No se pudo actualizar el producto');
        }

        res.redirect('/shop');
    } catch (error) {
        console.error('Error al editar el producto:', error.message);
        res.status(500).send('Error interno del servidor');
    }
},

    
    
      delete: async (req, res) => {
        const { id } = req.params;
        //res.send('quieres borrar el item ' + id);
    
    
        await deleteOne({ product_id: id });
        res.redirect('/admin');
    
    
      }
    };