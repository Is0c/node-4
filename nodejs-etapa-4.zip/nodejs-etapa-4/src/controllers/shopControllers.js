const { getAll, getOne } = require('../models/productModels');


module.exports = {
    shop: async (req, res) => {

        const data = await getAll();
       
        res.render('shop/shop', {
            title: 'Productos',
            data
        });
        
        console.log(data);
    },
    item: async (req, res) => {
        try {
            const itemId = req.params.id;
            console.log('ID recibido en el controlador:', itemId);
    
            // Pasar el id dentro de un objeto con la propiedad product_id
            const [item] = await getOne({ product_id: itemId });
    
            console.log('Producto obtenido:', item);
    
            if (!item || item.length === 0) {
                return res.status(404).send('Producto no encontrado');
            }
    
            res.render('shop/item', {
                title: 'Item',
                item
            });
        } catch (error) {
            console.error('Error al cargar el producto en la tienda:', error.message);
            res.status(500).send('Error interno del servidor');
        }
    },
    
    addItem: (req, res) => res.send("esta es la ruta para agregar un item al carrito"),

    cart: (req, res) => {
        res.render('shop/cart');
    },

    addCart: (req, res) => res.send("ruta para proceder a la compra")
};
